<?php
// @codingStandardsIgnoreStart
CModule::AddAutoloadClasses(
    "roistat.b24",
    array(
        "CRoistatB24" => "classes/general/roistat.php",
    )
);
// @codingStandardsIgnoreEnd