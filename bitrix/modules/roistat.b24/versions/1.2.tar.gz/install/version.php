<?php
// @codingStandardsIgnoreStart
$arModuleVersion = array(
	"VERSION" => "1.0.5",
	"VERSION_DATE" => "2017-12-28 14:34:24"
);
// @codingStandardsIgnoreEnd