<?php
// @codingStandardsIgnoreStart
$MESS['ROISTAT_TAB_NAME'] = 'Настройки';
$MESS['ROISTAT_TAB_TITLE'] = 'Настройки';
$MESS['ROISTAT_LOGIN_LABEL'] = 'Логин';
$MESS['ROISTAT_PASSWORD_LABEL'] = 'Пароль';
// @codingStandardsIgnoreEnd