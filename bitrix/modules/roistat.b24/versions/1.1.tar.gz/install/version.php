<?php
// @codingStandardsIgnoreStart
$arModuleVersion = array(
	"VERSION" => "1.0.4",
	"VERSION_DATE" => "2015-11-11 20:33:24"
);
// @codingStandardsIgnoreEnd