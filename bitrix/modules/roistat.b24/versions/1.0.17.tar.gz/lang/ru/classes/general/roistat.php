<?php
// @codingStandardsIgnoreStart
$MESS ['ROISTAT_MANAGER'] = "Менеджер";
$MESS ['ROISTAT_TYPE'] = "Тип";
$MESS ['ROISTAT_SOURCE'] = "Источник";
$MESS ['ROISTAT_YES'] = "Да";
$MESS ['ROISTAT_NO'] = "Нет";
// @codingStandardsIgnoreEnd