<?php
// @codingStandardsIgnoreStart
$MESS ['ROISTAT_MODULE_NAME'] = "Roistat";
$MESS ['ROISTAT_MODULE_DESCRIPTION'] = "Модуль интеграции Битрикс24.Коробка с системой аналитики Roistat";
$MESS ['ROISTAT_INSTALL_TITLE'] = "Установка модуля Roistat";
$MESS ['ROISTAT_DENIED'] = "закрыт";
$MESS ['ROISTAT_READ'] = "просмотр без права модификации";
$MESS ['ROISTAT_WRITE'] = "полный доступ";
$MESS ['ROISTAT_PROPERTY_NAME'] = 'Идентификатор roistat';
$MESS ['ROISTAT_PROPERTY_DESCRIPTION'] = 'Идентификатор пользователя на сервере roistat';
$MESS ['ROISTAT_ERROR_ADD_PROPERTY'] = 'Ошибка добавления свойства для заказа';
// @codingStandardsIgnoreEnd