<?php
// @codingStandardsIgnoreStart
$arModuleVersion = array(
	"VERSION" => "1.0.17",
	"VERSION_DATE" => "2018-11-23 10:45:00"
);
// @codingStandardsIgnoreEnd