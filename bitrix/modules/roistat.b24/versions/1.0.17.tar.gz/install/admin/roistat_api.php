<?php
// @codingStandardsIgnoreStart
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/roistat.b24/admin/api.php");
// @codingStandardsIgnoreEnd